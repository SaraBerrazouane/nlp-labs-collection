#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This is a paart of NLP labs, ESI, Algiers 
# --------------------------------------------------------------------
# Copyright (C) 2025 Abdelkrime Aries (kariminfo0@gmail.com)
# 
# Autors: 
#        - 2025 Abdelkrime Aries (kariminfo0@gmail.com)
# Contributors:
#        - 
#        - 
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
# http://www.apache.org/licenses/LICENSE-2.0
#  
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import math
import json
import random
from functools import reduce
from typing import Dict, List, Tuple, Set, Union, Any

from myapi.mat_func import mat_add_vec, mat_dot, mat_ew_op, mat_mean, mat_mean_std, mat_normalize, mat_random, mat_smul, mat_softmax, mat_transpose, mat_val
from . import Layer
from myapi.vec_func import vec_dot, vec_ew_add, vec_ew_mul, vec_ew_op, vec_ew_sub, vec_random, vec_softmax, vec_sum, vec_val


# since there is no sequence in herem no need to implement forward_single
# mostly, it is forward function that uses forward_single (for simplification)
# but, in here, we'll do the inverse
class Linear(Layer):

    def __init__(self, in_size: int, out_size: int, bias: bool = False) -> None:
        """A Linear layer with many neurons.
        Args:
            in_size (int): the number of features in input (do not count bias)
            out_size (int): the number of neurons (the output)
            bias (bool): is there a bias or not
        """
        self.w = mat_random(out_size, in_size)
        self.bias = bias
        if bias:
            self.b = vec_random(out_size)
    
    def forward_single(self, X: List[float]) -> List[float]:
        """Given some input, predict the output (one sample)

        Args:
            X (List[float]): Encoded input

        Returns:
            List[float]: The output
        """
        return self.forward([X])[0]
    
    def forward(self, Xs: List[List[float]]) -> List[List[float]]:
        """Given some input, predict the output (many samples)

        Args:
            Xs (List[List[float]]): Encoded input

        Returns:
            List[List[float]]: The output
        """
        self.Xs = Xs  # Save input for backward
        Ys = mat_dot(Xs, self.w)
        if self.bias:
            Ys = mat_add_vec(Ys, self.b)
        return Ys 

    def backward_single(self, dY: List[float], alpha:float=0.01) -> None:
        """Updates the weights of the neurons

        Args:
            dY (List[float]): List of losts 
            alpha (float, optional): update factor. Defaults to 0.01.
        """
        return self.backward([dY], alpha=alpha)
    
    def backward(self, dYs: List[List[float]], alpha:float=0.01) -> None:
        """Updates the weights of the neurons

        Args:
            dYs (List[List[float]]): List of losts 
            alpha (float, optional): update factor. Defaults to 0.01.
        """
        # normalize ( no need, It is supposed the gradients are normalized in the loss function)
        # alpha /= len(self.X)

        # calculate the gradient 
        # Grad w.r.t weights: dJ/dW = dY^T @ X
        dW =  mat_dot(mat_transpose(dYs), self.X)

        # Update weights
        self.w = mat_ew_op(self.w, dW, lambda w, g: w - alpha * g)

        # Update bias
        if self.bias:
            self.w = vec_ew_op(self.w, mat_transpose(dW), lambda w, G: w - alpha * vec_sum(G))

        # Gradient to pass to previous layer (dY @ W)
        return mat_dot(dYs, self.w)  # [batch_size, in_size]




# ====================================================
# ======================= TODO =======================
# ====================================================

class Embedding(Layer):

    def __init__(self, vocab_size: int, embed_dim: int) -> None:
        """An Embedding layer mapping tokens to vectors."""
        self.w = mat_random(vocab_size, embed_dim)

    def forward_single(self, X: List[int]) -> List[List[float]]:
        """Forward pass for one sequence.

        Args:
            X (List[int]): one sequence

        Returns:
            List[List[float]]: embedded sequence
        """
        # Get embedding vector for each token in the sequence
        return [self.w[token] for token in X]

    def forward(self, Xs: List[List[int]]) -> List[List[List[float]]]:
        """Forward pass for a batch of sequences.

        Args:
            Xs (List[List[int]]): batch of sequences

        Returns:
            List[List[List[float]]]: embedded sequences
        """
 
        # Save input for backward pass
        self.Xs = Xs
        
        # Get embeddings for each token in each sequence in the batch
        return [self.forward_single(X) for X in Xs]

    def backward_single(self, dY: List[List[float]], alpha: float = 0.01) -> None:
        """Backward pass for a batch of sequences.

        Args:
            dY (List[List[float]]): gradients from upper layers
            alpha (float, optional): learning rate
        """

        # Iterate over all vocabulary indices (each embedding vector)
        for v in range(len(self.w)):
            # Initialize the accumulated gradient for token v as a zero vector
            grad_sum = vec_val(len(self.w[v]), 0.0)

            # Loop through all tokens in the input sequence self.X
            for t in range(len(self.X)):
                # If the token at position t is equal to index v
                if self.X[t] == v:
                    # Add the corresponding output gradient at position t
                    grad_sum = vec_ew_add(grad_sum, dY[t])

            # Update the embedding vector for token v using gradient descent
            self.w[v] = vec_ew_op(self.w[v], grad_sum, lambda w, g: w - alpha * g)




    def backward(self, dYs: List[List[List[float]]], alpha: float = 0.01) -> None:
        """Backward pass for a batch of sequences.

        Args:
            dYs (List[List[List[float]]]): gradients from upper layers
            alpha (float, optional): learning rate
        """

        # Loop through each sequence in the batch
        for m in range(len(dYs)):
            # Select the corresponding input sequence
            self.X = self.Xs[m]
            # Apply the backward pass for that sequence
            self.backward_single(dYs[m], alpha)





class LayerNorm(Layer):
    def __init__(self, dim: int, eps: float = 1e-5) -> None:
        self.eps = eps
        self.gamma = vec_val(dim, 1.0)  # shape: (features,)
        self.beta = vec_val(dim, 0.0)   # shape: (features,)

    def forward(self, X: List[List[List[float]]]) -> List[List[List[float]]]:
        """Forward pass for LayerNorm.
        
        Args:
            X: Input tensor of shape (batch_size, seq_len, features)
            
        Returns:
            Normalized tensor of same shape as input
        """
        self.X = X

        self.mean, self.std, self.norm = [], [], []

        O = []

        # For each sample in the batch
        for x_batch in X:
            batch_mean = []
            batch_std = []
            batch_norm = []
            batch_output = []
            
            # For each sequence position
            for x in x_batch:
                # Calculate mean and standard deviation with precise division
                n = len(x)
                mean = sum(x) / n
                var = sum((xi - mean) ** 2 for xi in x) / n
                std = math.sqrt(var + self.eps)
                
                # Normalize the input with precise calculations
                norm_x = [(xi - mean) / std for xi in x]
                
                # Scale and shift with gamma and beta
                output = vec_ew_add(vec_ew_mul(norm_x, self.gamma), self.beta)
                
                # Store for backward pass
                batch_mean.append(mean)
                batch_std.append(std)
                batch_norm.append(norm_x)
                batch_output.append(output)
                
            self.mean.append(batch_mean)
            self.std.append(batch_std)
            self.norm.append(batch_norm)
            O.append(batch_output)
            
        return O

    def backward(self, dY: List[List[List[float]]], alpha: float = 0.01) -> List[List[List[float]]]:
        """
        dY shape: (batch_size, seq_len, features)
        """
        # Gradients w.r.t gamma and beta
        dgamma = vec_val(len(self.gamma), 0.0)
        dbeta = vec_val(len(self.beta), 0.0)

        # First pass: compute dgamma and dbeta
        for m in range(len(dY)):
            for t in range(len(dY[m])):
                for i in range(len(self.gamma)):
                    dgamma[i] += dY[m][t][i] * self.norm[m][t][i]
                    dbeta[i] += dY[m][t][i]

        # Update gamma and beta
        self.gamma = vec_ew_op(self.gamma, dgamma, lambda g, dg: g - alpha * dg)
        self.beta = vec_ew_op(self.beta, dbeta, lambda b, db: b - alpha * db)

        # Second pass: compute dX
        dX = []
        for x_batch, dy_batch, mean_batch, std_batch in zip(self.X, dY, self.mean, self.std):
            dX_batch = []

            for x, dy, mu, std in zip(x_batch, dy_batch, mean_batch, std_batch):
                dx_norm = vec_ew_mul(dy, self.gamma)

                dvar = vec_sum([
                    dx_norm[j] * (x[j] - mu) * -0.5 / (std ** 3)
                    for j in range(len(x))
                ])

                dmean = vec_sum([
                    -dx_norm[j] / std for j in range(len(x))
                ]) + dvar * vec_sum([
                    -2 * (x[j] - mu) for j in range(len(x))
                ]) / len(x)

                dx = [
                    dx_norm[j] / std +
                    dvar * 2 * (x[j] - mu) / len(x) +
                    dmean / len(x)
                    for j in range(len(x))
                ]
                dX_batch.append(dx)

            dX.append(dX_batch)

        return dX


class ScaledDotProductAttention(Layer):
    def __init__(self) -> None:
        pass  # No learnable parameters

    def forward_single(self, Q: List[List[float]], K: List[List[float]], V: List[List[float]], M: List[List[bool]] = None) -> Tuple[List[List[float]], List[List[float]], List[List[float]]]:
        """Forward for a single sample (T, d)."""

        # Transpose the Key matrix to compute dot-product with Queries
        K_T = mat_transpose(K)

        # Feature dimension (d)
        N = len(Q[0])

        # Compute raw attention scores: S = Q · Kᵀ
        S = mat_dot(Q, K_T)

        # Scale the scores by 1/√N (temperature scaling)
        S = mat_smul(S, 1 / math.sqrt(N))

        # Apply softmax to get attention weights; use mask if provided
        P = mat_softmax(S, M)

        # Multiply attention weights with Values to get the output
        Y = mat_dot(P, V)

        return Y, S, P

    def forward(self, Qs: List[List[List[float]]], Ks: List[List[List[float]]], Vs: List[List[List[float]]], Ms: List[List[List[bool]]] = None) -> List[List[List[float]]]:
        """Forward for a batch of samples (M, T, d)."""
        self.Qs, self.Ks, self.Vs, self.Ms = Qs, Ks, Vs, Ms

        self.Ss = []
        self.Ps = []
        Ys      = []

        # Compute forward pass for each sample in the batch
        for i in range(len(Qs)):
            Q = Qs[i]
            K = Ks[i]
            V = Vs[i]
            M = Ms[i] if Ms is not None else None

            # Apply scaled dot-product attention to a single sample
            Y, S, P = self.forward_single(Q, K, V, M)

            # Collect outputs and intermediate values
            Ys.append(Y)
            self.Ss.append(S)
            self.Ps.append(P)

        return Ys

    def backward_single(self, dY: List[List[float]], alpha: float = 0.01) -> Tuple[List[List[float]], List[List[float]], List[List[float]]]:
        """Backward for a single sample (T, d)."""

        m = self.index  # index of sample in batch
        P = self.Ps[m]
        V = self.Vs[m]
        K = self.Ks[m]
        Q = self.Qs[m]
        N = len(Q[0])  # Dimension of features

        # ∂J/∂P = ∂J/∂Y · Vᵀ
        dP = mat_dot(dY, mat_transpose(V))

        # ∂J/∂S = P ⊙ (∂J/∂P - sum(P * ∂J/∂P))
        dS = []
        for t in range(len(P)):
            dS_row = []
            sum_P_dP = vec_sum([P[t][j] * dP[t][j] for j in range(len(P[t]))])
            for j in range(len(P[t])):
                dS_tj = P[t][j] * (dP[t][j] - sum_P_dP)
                dS_row.append(dS_tj)
            dS.append(dS_row)

        scale = 1 / math.sqrt(N)

        # ∂J/∂Q = (1/√N) · (∂J/∂S · K)
        dQ = mat_smul(mat_dot(dS, K), scale)

        # ∂J/∂K = (1/√N) · (∂J/∂S)ᵀ · Q
        dK = mat_smul(mat_dot(mat_transpose(dS), Q), scale)

        # ∂J/∂V = Pᵀ · ∂J/∂Y
        dV = mat_dot(mat_transpose(P), dY)

        return dQ, dK, dV

    def backward(self, dYs: List[List[List[float]]], alpha: float = 0.01) -> Tuple[List[List[List[float]]], List[List[List[float]]], List[List[List[float]]]]:
        """Backward for a batch of samples (M, T, d)."""
        dQs = []
        dKs = []
        dVs = []

        
        for m in range(len(dYs)):
            self.index = m  # we define the index to use in  backward_single
            dQ, dK, dV = self.backward_single(dYs[m], alpha)
            dQs.append(dQ)
            dKs.append(dK)
            dVs.append(dV)

        return dQs, dKs, dVs


