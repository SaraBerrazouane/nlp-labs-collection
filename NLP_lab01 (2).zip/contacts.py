import re

# Emails 
mails = [
    (re.compile(r'([\w.-]+)@(\w+)\.(\w+)'), '$1@$2.$3')
]

# Social Media
socials = [
    # Facebook - Exclude "sharer"
    (re.compile(r'https?://(www\.)?facebook\.com/(?!sharer)([A-Za-z0-9._-]+)', re.IGNORECASE), 'facebook:$2'),

    # Twitter - Exclude "intent"
    (re.compile(r'https?://(www\.)?twitter\.com/(?!intent)([A-Za-z0-9_]+)', re.IGNORECASE), 'twitter:$2'),

    # Instagram
    (re.compile(r'https?://(www\.)?instagram\.com/([A-Za-z0-9._-]+)', re.IGNORECASE), 'instagram:$2'),

    # LinkedIn (only "company" type)
    (re.compile(r'https?://(www\.)?linkedin\.com/company/([A-Za-z0-9-]+)', re.IGNORECASE), 'linkedin:$2'),

    # YouTube (only "channel" type)
    (re.compile(r'https?://(www\.)?youtube\.com/channel/([A-Za-z0-9_-]+)', re.IGNORECASE), 'youtube:$2')
]



# Phone Numbers 
tels = [
    # Standard phone numbers with or without country code
    (re.compile(r'''
        (?:\+?213|00\s?213|\+213\s?\(0\))?   # Optional country code
        \s*
        \(?0([1-4]\d|5\d{2}|6\d{2}|7\d{2})\)?  # Valid area codes
        [\s.-]*                              # Separator
        ([1-9]\d)                            # First part of the number (no leading zeros)
        [\s.-]*                              # Separator
        (\d{2})                              # Second part of the number
        [\s.-]*                              # Separator
        (\d{2})                              # Last part of the number
        (?!\d)                               # No more digits after this
    ''', re.VERBOSE), '(0$1) $2 $3 $4'),

    # Handling the variations: /XX, a XX, ou XX
    (re.compile(r'''
        (?:\+?213|00\s?213|\+213\s?\(0\))?   # Optional country code
        \s*
        \(?0([1-4]\d|5\d{2}|6\d{2}|7\d{2})\)?  # Valid area codes
        [\s.-]*                              # Separator
        ([1-9]\d)                            # First part of the number (no leading zeros)
        [\s.-]*                              # Separator
        (\d{2})                              # Second part of the number
        [\s.-]*                              # Separator
        (\d{2})                              # Last part of the number
        (?:\s*(?:/|a|ou)\s*(\d{2}))+          # Variations like /XX, a XX, ou XX
    ''', re.VERBOSE), lambda m: ' et '.join([
        f'(0{m.group(1)}) {m.group(2)} {m.group(3)} {v}'
        for v in [m.group(4)] + re.findall(r'(?:/|a|ou)\s*(\d{2})', m.group(0))
    ]))
]
