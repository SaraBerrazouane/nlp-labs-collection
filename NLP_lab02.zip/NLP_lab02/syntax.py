#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Submit just this file, no zip, no additional files
# -------------------------------------------------

# Students:
#     - Berrazouane Sara


"""QUESTIONS/ANSWERS

----------------------------------------------------------
Q1: "If PoS tagging is used with CKY, there will be no ambiguities". True or False? Justify.

A1: False.
Even with POS tagging, ambiguities can still exist in CKY parsing. POS tagging assigns a category to each word, 
but a sentence can still have multiple valid parse trees due to structural ambiguity. Different parse trees 
can represent different meanings even if POS tags are correctly assigned.

----------------------------------------------------------
Q2: If PoS tagging is used with CKY, there will be no out-of-vocabulary problem". True or False? Justify.

A2: False.
POS tagging does not completely solve the out-of-vocabulary (OOV) problem. If a word is not in the
training data, the POS tagger may fail to assign a tag or assign an incorrect one. CKY relies on predefined 
grammar rules, so if a word is missing, the parser may not find a valid parse, leading to errors.

"""

import re
import random
from typing import Dict, List, Tuple, Set


# ======================================================
#                   Analyse CKY
# ======================================================

class CKY:
    def __init__(self, gram: List[Tuple[str, str, str]], lex: Dict[str, List[str]]):
        # Grammar
        self.gram = gram # list((A, B, C)| (A, B)) : A -> B C | A -> B
        self.lex = lex # word --> liste(PoS)

    # TODO: Complete this method
    def parse(self, sent: List[str]) -> List[List[List[Tuple[str, int, int, int]]]]:
        T = []
        N = len(sent)
        for i in range(N):
            T.append([[] for i in range(N)])
            word = sent[i]
            for A in self.lex[word]: # The word is supposed to exist in the lexicon
                T[i][i].append((A, -1, -1, -1)) # All possible leaves are added
            
        # Applying unary rules to the diagonal (leaf nodes)
        for i in range(N):
            added = True
            while added:  # continue until no more unary rules can be applied
                added = False
                current_cell = T[i][i].copy()
                for B, idx_B in [(entry[0], idx) for idx, entry in enumerate(current_cell)]:
                    for A, C in [(rule[0], rule[1]) for rule in self.gram if len(rule) == 2]:  # Unary rules
                        if C == B and not any(entry[0] == A for entry in T[i][i]):  # to avoid duplicates
                            T[i][i].append((A, i, idx_B, -1))
                            added = True  # to ensure another pass to apply new added rules

        # Filling the CKY table bottom-up
        for span in range(1, N):  # span defines the length of the subsequence being analyzed
            for i in range(N - span):  # i : the start index
                j = i + span  # j : the end index

                # Trying all possible splits between i and j
                for k in range(i, j):
                    # Checking all binary production rules (A -> B C)
                    for A, B, C in [(rule[0], rule[1], rule[2]) for rule in self.gram if len(rule) == 3]:
                        # Finding B in T[i][k]
                        for idx_B, entry_B in enumerate(T[i][k]):
                            if entry_B[0] == B:
                                # Finding C in T[k+1][j]
                                for idx_C, entry_C in enumerate(T[k+1][j]):
                                    if entry_C[0] == C:
                                        # Adding non-terminal A to T[i][j] with backpointers to B and C
                                        T[i][j].append((A, k, idx_B, idx_C))

                # Applying unary rules to the newly filled cell
                added = True
                while added:
                    added = False
                    current_cell = T[i][j].copy()
                    for B, idx_B in [(entry[0], idx) for idx, entry in enumerate(current_cell)]:
                        for A, C in [(rule[0], rule[1]) for rule in self.gram if len(rule) == 2]:  # Unary rules
                            if C == B and not any(entry[0] == A for entry in T[i][j]):  # to avoid duplicates
                                T[i][j].append((A, j, idx_B, -1))
                                added = True  # continue applying unary rules if new ones are added
                            
        return T  

    def export_json(self):
        return self.__dict__.copy()

    def import_json(self, data):
        for key in data:
            self.__dict__[key] = data[key]

# ======================================================
#                Parsing
# ======================================================
def count_arcs(tree, arcs=None, index=0):
    #  to count the number of arcs in a tree with positional indices
    if arcs is None:
        arcs = set()
    
    if isinstance(tree, tuple) and len(tree) > 1:
        root = (tree[0], index)  # annotating the node with its position
        for i, child in enumerate(tree[1:]):  # iterate with positional index
            if isinstance(child, tuple):
                child_node = (child[0], index + i + 1)  # Assigning a unique position
                arcs.add((root, child_node))  # Storing the arcs with positions
                count_arcs(child, arcs, index + i + 1)  # Recursive call with new index

    return arcs

# TODO: Complete this method

def pr_eval(ref, sys):

    if ref is None and sys is None:
        return 1.0, 1.0
    if ref is None or sys is None:
        return 0.0, 0.0

    ref_arcs = count_arcs(ref) 
    sys_arcs = count_arcs(sys)

    TP = len(ref_arcs & sys_arcs)  # True Positives 
    P = TP / len(sys_arcs) if sys_arcs else 0.0  # Precision
    R = TP / len(ref_arcs) if ref_arcs else 0.0  # Recall

    return P, R


def construct(T, sent, i, j, pos):
    A, k, iB, iC = T[i][j][pos]
    #A = A.upper()
    if k >= 0:
        left = construct(T, sent, i, k, iB)
        if iC == -1:
            return (A, left)
        right = construct(T, sent, k+1, j, iC)
        return (A, left, right)
    return (A, sent[i])

def parse_tuple(string):
    string = re.sub(r'([^\s(),]+)', "'\\1'", string)
    #print(string)
    try:
        s = eval(string)
        if type(s) == tuple:
            return s
        return
    except:
        return

class Syntax():
    def __init__(self):
        self.eval = []

    def _parse(self, sent):
        r = None
        T = self.model.parse(sent)
        n = len(sent) - 1
        # for i in range(n+1):
        #     for j in range(i, n+1):
        #         print(i+1, j+1, T[i][j])
        for pos in range(len(T[0][n])):
            if T[0][n][pos][0] == 'S':
                # print('bingo')
                r = construct(T, sent, 0, n, pos)
                break
        return r

    def parse(self, sent: str):
        return self._parse(sent.strip().lower().split())

    def load_model(self, url):
        f = open(url, 'r')
        lex = {}
        gram = []
        for l in f: # line-by-line reading
            l = l.strip()
            if len(l) < 3 or l.startswith('#') :
                continue
            info = l.split('	')
            if len(info) == 2:
                if info[1][0].isupper():
                    gram.append((info[0], info[1]))
                else:
                    if not info[1] in lex:
                        lex[info[1]] = []
                    lex[info[1]].append(info[0])
            elif len(info) == 3:
                gram.append((info[0], info[1], info[2]))
        self.model = CKY(gram, lex)
        f.close()


    def load_eval(self, url):
        f = open(url, 'r')
        for l in f: # line-by-line reading
            l = l.strip()
            if len(l) < 5 or l.startswith('#'):
                continue
            info = l.split('	')
            
            self.eval.append((info[0], parse_tuple(info[1])))

    def evaluate(self, n):
        if n == -1:
            S = self.eval
            n = len(S)
        else :
            S = random.sample(self.eval, n)
        P, R = 0.0, 0.0
        for i in range(n):
            test = S[i]
            print('=======================')
            print('sent:', test[0])
            print('ref tree:', test[1])
            tree = self.parse(test[0])
            print('sys tree:', tree)
            P_i, R_i = pr_eval(test[1], tree)
            print('P, R:', P_i, R_i)
            P += P_i
            R += R_i

        P, R = P/n, R/n
        print('---------------------------------')
        print('P, R: ', P, R)



# ======================================================
#        Graph generation (Dot language)
# ======================================================

def generate_node(node, id=0):
    # If the node does not exist
    if node is None:
        return 0, ''
    # If the node is final
    nid = id + 1
    if len(node) < 3:
        return nid, 'N' + str(id) + '[label="' + node[0] + "=" + node[1] + '" shape=box];\n'
    # Otherzise,
    # If there are children, print if else
    res = 'N' + str(id) + '[label="' + node[0] + '"];\n'
    nid_l = nid
    nid, code = generate_node(node[1], id=nid_l)
    res += code
    res += 'N' + str(id) + ' ->  N' + str(nid_l) + ';\n'
    if len(node) > 2:
        nid_r = nid
        nid, code = generate_node(node[2], id=nid_r)
        res += code
        res += 'N' + str(id) + ' ->  N' + str(nid_r) + ';\n'
    return nid, res

def generate_graphviz(root, url):
    res = 'digraph Tree {\n'
    id, code = generate_node(root)
    res += code
    res += '}'
    f = open(url, 'w')
    f.write(res)
    f.close()


# ======================================================
#                       TESTES
# ======================================================

# Test in the lecture
def test_cky():
    parser = Syntax()
    parser.load_model('data/gram1.txt')
    sent = 'la petite forme une petite phrase'
    result = "('S', ('NP', ('D', 'la'), ('N', 'petite')), ('VP', ('V', 'forme'), ('NP', ('D', 'une'), ('AP', ('J', 'petite'), ('N', 'phrase')))))"
    tree = parser.parse(sent)
    print('Real Result: ', result)
    print('My Result: ', tree)
    generate_graphviz(tree, 'parse_tree.gv')

# test the pr evaluation
def test_eval_tree():
    t1 = ('A', ('B', 'b'), ('C', ('A', 'a'), ('B', ('A', 'a'), ('C', 'c'))))
    t2 = ('A', ('B', 'b'), ('C', ('B', 'b'), ('D', 'd')))
    t3 = ('A', ('B', 'b'), ('C', ('B', 'b')))
    print('Real: (0., 0.), Found: ', pr_eval(None, t1))
    print('Real: (1., 1.), Found: ', pr_eval(None, None))
    print('Real: (0.5, 0.333), Found: ', pr_eval(t1, t2))
    print('Real: (0.333, 0.5), Found: ', pr_eval(t2, t1))
    print('Real: (1., 0.75), Found: ', pr_eval(t2, t3))
    print('Real: (1., 1.), Found: ', pr_eval(t1, t1))
# evaluate an existing example
def test_evaluate():
    parser = Syntax()
    parser.load_model('data/gram1.txt')
    parser.load_eval('data/test1.txt')
    parser.evaluate(-1)


if __name__ == '__main__':
    test_cky()
    test_eval_tree()
    test_evaluate()
